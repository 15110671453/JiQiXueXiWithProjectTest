/*
angularjs 启动主流程
教程 1.3.0.14

sublime 查找函数 command+r 
sublime 跳到对应的行 ctrl+g
我们这里又使用了ionic ionic是在angularjs基础上的扩展
这里需要回顾angularjs的启动顺序
检查angularjs 是否已经启动过
publishExternalAPI(angular) 将angular工具函数扩展到angular对象
调用setupModuleLoader(window) 构建模块加载器
在setupModuleLoader方法中注册了内核provider（两个最重要的provider parse与rootScope）
angularInit 防止多次初始化ng-app 
bootstrap 创建injector 拉起内核和启动模块  调用compile服务

第一：
angularjs 
1、为什么要依赖注入
2、ng中最简单的依赖注入的例子
3、ng中三种依赖注入的方式 推断式注入 标注式注入 内联注入
4、直接使用$injector(一般很少用)
5、provider模式与ng是如何实现provider的
6、provider factory service constant value decorator 理解angularjs的概念
7、内置的provider分析 $ControllerProvider
8、injector源码分析 创建 注册 调用

 $scope就是注入

第二：
provider 策略模式 工厂模式
为了让接口和实现分离
在ng中 所有provider都可以用来进行注入
注入两个角色 被注入 可以用来进行注入
以下类型可以进行注入
：provider factory service constant value
以下类型函数可以接受注入
controller directive filter service factory

ng中依赖注入是通过provider和injector这两个机制联合实现的

首先看provider provider是最复杂的

*/

var myModule = angular.module("MyModule",[]);

myModule.provider("HelloAngular",function(){
	return {
		/*provider 返回一个对象*/
		$get:function(){
			var name = 'IMOOC';
			function getName(){
				return name;
			}
			return {
				getName:getName;
			}
		}
	}
});
/*provider是基础 service factory value constant 都是在provider上扩展*/

myModule.factory('HelloAngular',  function(){
      var name = 'imoocFactory';
      function getName(){
      	return name;
      }
      return {
      	getName:getName;
      }
});

myModule.service('HelloAngular',  function(){
	this.name = 'imooc service';
	this.getName = function(){
		return this.name;
	}
});

/*
ControllerProvider 这里需要 provider 中一定要有$get方法
ControllerProvider 是provider 的子类？？？
*/
myModule.controller('MyCtrl', ['scope', 'HelloAngular',function(){
	function($scope,helloAngular){
		$scope.getName = helloAngular.getName();
	}
}]);







