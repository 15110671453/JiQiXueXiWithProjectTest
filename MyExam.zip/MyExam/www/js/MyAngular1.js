
/*
指令的执行过程分析
bootstrap 启动时 会启动compile服务 compile服务会去查找并编译指令

外部逻辑使用directive方法注册指令
指令执行过程分析：
从ng-app开始 递归子层DOM结构 收集指令
如果有需要 为指令生成childScope；childScope绑定到元素的data属性上
调用每个指令自己的compile函数生成compositeLinkFn函数
编译的结果是返回一个publicLinkFn函数

*/

/*

angular的指令的执行 指令的执行过程分析

angular的指令的执行   
自定义compile与link函数
compile与link的区别
从最简单的<HelloAngular>例子分析指令的源代码



*/

var myModule = angular.module('MyModule',[]);

myModule.directive('hello',  function(){
	// Runs during compile
	return {
		// name: '',
		// priority: 1,
		// terminal: true,
		// scope: {}, // {} = isolate, true = child, false/undefined = no change
		// controller: function($scope, $element, $attrs, $transclude) {},
		// require: 'ngModel', // Array = multiple requires, ? = optional, ^ = check parent elements
		// restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		// template: '',
		// templateUrl: '',
		// replace: true,
		// transclude: true,
		// compile: function(tElement, tAttrs, function transclude(function(scope, cloneLinkingFn){ return function linking(scope, elm, attrs){}})),
		
		restrict: 'E', 
		template: '<div>Hi everyOne link </div>',
		replace: true,
        /*
        四个参数
        第一个 scope
        第二个 element
        第三个 属性
        第四个 controller
        */
		link: function($scope, iElm, iAttrs, controller) {
			// console.log("hello link");
			iElm.on("mouseenter",function(){
				console.log("鼠标进入....");
			});

		}
	};
});


myModule.directive('compileHello',  function(){
	// Runs during compile
	return {
		// name: '',
		// priority: 1,
		// terminal: true,
		// scope: {}, // {} = isolate, true = child, false/undefined = no change
		// controller: function($scope, $element, $attrs, $transclude) {},
		// require: 'ngModel', // Array = multiple requires, ? = optional, ^ = check parent elements
		// restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		// template: '',
		// templateUrl: '',
		// replace: true,
		// transclude: true,
		// compile: function(tElement, tAttrs, function transclude(function(scope, cloneLinkingFn){ return function linking(scope, elm, attrs){}})),
		
		restrict: 'A', 
		
        /*
        四个参数
        第一个 scope
        第二个 element
        第三个 属性
        第四个 controller
        */
	     
	compile: function(tElement, tAttrs,function transclude(function(scope, cloneLinkingFn){ 
						return function linking(scope, elm, attrs){


			}}))
});


/*
compile的函数作用是对指令的模版进行转换的
link的作用是在模型和视图之间建立关联，包括在元素上注册事件监听
scope在链接阶段才会绑定到元素上 因此compile阶段无法操作scope 只有link阶段才可以操作scope
对于同一个指令的多个实例 compile只会执行一次 link执行多次
一般情况下 我们只要编写link函数
如果编写了compile函数 compile会返回一个link函数 那么自定义的link函数就会失效
*/
/*
指令的执行过程分析
bootstrap 启动时 会启动compile服务 compile服务会去查找并编译指令

外部逻辑使用directive方法注册指令
指令执行过程分析：
从ng-app开始 递归子层DOM结构 收集指令
如果有需要 为指令生成childScope；childScope绑定到元素的data属性上
调用每个指令自己的compile函数生成compositeLinkFn函数
编译的结果是返回一个publicLinkFn函数

*/





