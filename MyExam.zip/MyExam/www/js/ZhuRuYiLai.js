var myModule = angular.module("MyModule",[]);

//推断式注入
var MyCtrl = function($scope){
	$scope.gameName = "大漠吃豆子"
}
//声明式注入 标注式注入
MyCtrl.$injector = ['$scope']

myModule.controller('MyCtrl', MyCtrl);

//内联式注入
myModule.controller('MyCtrl', ['$scope', function($scope){
	$scope.gameName = "内联式注入";
	
}])


/*
注射器有两种类型
第一种providerinjector
第二种instanceInjector
angular 内部自己使用注射器 参数注入 函数注入
一般不需要开发人员自己来
*/
//factory 定义一个服务
myModule.factory('game', [ function(){
	return {
		gameName:'大漠吃豆子factory'
	}
}])


myModule.controller('MyCtrl', ['$scope','$injector', function($scope,$injector){

      console.log($injector);
       $injector.invoke(function(game){
       	console.log(game,gameName);
       });
       console.log($injector);
       //分析函数签名
       console.log($injector.annotate(function(arg0,arg1){

         }));

	
}])













