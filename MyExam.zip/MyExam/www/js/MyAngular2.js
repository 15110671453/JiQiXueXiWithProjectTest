/*
回顾双向数据绑定实例
思考问题 ng是如何发现数据发生了变化的
源码导读 关于scope
思考问题 被绑定对象的结构
绑定过程中使用表达式
ng支持那些形式的表达式
自己动手实现双向数据绑定（**难度大 初学者慎入 需要扎实的js基础）
*/

var myModule = angular.module('MyModule',[]);
myModule.controller('MyCtrl',  ['$scope',function($scope){
		$scope.greeting = 'Hello 双向数据绑定{{}} ' ;	
}]);

/*
  我们可以看出双向数据绑定和$scope有紧密的联系
*/

/*
从ng-app收集指令 找到ng-app后 会创建rootScope对象 

双向数据绑定scope
进行数据绑定 
需要注意：
除了最简单的表单 
一维数据结构 {email:123@qq.com,paswd:123456}
表格数据 二维数据结构
[
{index:1,firstrName:'Mark',lastName:'Ding',age:18},
{index:1,firstrName:'Mark',lastName:'Ding',age:18},
{index:1,firstrName:'Mark',lastName:'Ding',age:18},
]

数据结构复杂 类似目录的tree型结构 angularjs 不搞笑 ，容易引起内存不足


由于ng的$digest机制和‘对象深比较’机制 ng在处理tree型结构方面
性能非常差
后面分析$digest源码的过程中会解释
*/




